/*
 Navicat Premium Data Transfer

 Source Server         : localhost
 Source Server Type    : MySQL
 Source Server Version : 50726
 Source Host           : localhost:3306
 Source Schema         : test

 Target Server Type    : MySQL
 Target Server Version : 50726
 File Encoding         : 65001

 Date: 04/12/2022 15:47:15
*/

SET NAMES utf8mb4;
SET FOREIGN_KEY_CHECKS = 0;

-- ----------------------------
-- Table structure for mr_admin
-- ----------------------------
DROP TABLE IF EXISTS `mr_admin`;
CREATE TABLE `mr_admin`  (
  `id` int(11) NOT NULL COMMENT '主键id',
  `adminname` varchar(255) CHARACTER SET utf8 COLLATE utf8_unicode_ci NULL DEFAULT NULL COMMENT '管理员用户名',
  `adminpass` varchar(255) CHARACTER SET utf8 COLLATE utf8_unicode_ci NULL DEFAULT NULL COMMENT '管理员密码',
  `adminqq` varchar(255) CHARACTER SET utf8 COLLATE utf8_unicode_ci NULL DEFAULT NULL COMMENT 'qq',
  `nickname` varchar(255) CHARACTER SET utf8 COLLATE utf8_unicode_ci NULL DEFAULT NULL COMMENT '昵称',
  `salt` varchar(255) CHARACTER SET utf8 COLLATE utf8_unicode_ci NULL DEFAULT NULL COMMENT '盐',
  `admintoken` varchar(255) CHARACTER SET utf8 COLLATE utf8_unicode_ci NULL DEFAULT NULL COMMENT '单点登录',
  `adminkey` varchar(255) CHARACTER SET utf8 COLLATE utf8_unicode_ci NULL DEFAULT NULL COMMENT '密钥',
  PRIMARY KEY (`id`) USING BTREE
) ENGINE = MyISAM CHARACTER SET = utf8 COLLATE = utf8_unicode_ci ROW_FORMAT = DYNAMIC;

-- ----------------------------
-- Records of mr_admin
-- ----------------------------
INSERT INTO `mr_admin` VALUES (1, 'moran', 'e18a0e29571c11b259c0295fee5ed125', '2659917175', '默然', 'Tbxt4n', 'a6b07af82a352247ceb2aa752c6d7845', '6f8657b7990d1dff01c6435b24936d04');

-- ----------------------------
-- Table structure for mr_app
-- ----------------------------
DROP TABLE IF EXISTS `mr_app`;
CREATE TABLE `mr_app`  (
  `appid` int(11) NOT NULL AUTO_INCREMENT COMMENT 'appid',
  `appname` varchar(255) CHARACTER SET utf8 COLLATE utf8_unicode_ci NULL DEFAULT NULL COMMENT 'app名称',
  `appicon` varchar(255) CHARACTER SET utf16 COLLATE utf16_general_ci NULL DEFAULT NULL COMMENT 'app图标',
  `introduction` longtext CHARACTER SET utf8 COLLATE utf8_unicode_ci NULL COMMENT '应用简介',
  `author` varchar(255) CHARACTER SET utf8 COLLATE utf8_unicode_ci NULL DEFAULT NULL COMMENT '开发者联系方式',
  `group` varchar(255) CHARACTER SET utf8 COLLATE utf8_unicode_ci NULL DEFAULT NULL COMMENT '官方群组',
  `create_time` datetime NULL DEFAULT NULL COMMENT '创建时间',
  `is_del` tinyint(1) NULL DEFAULT 0 COMMENT '0未删除1已删除',
  `zc_money` varchar(255) CHARACTER SET utf8 COLLATE utf8_unicode_ci NULL DEFAULT '0' COMMENT '注册赠送金币',
  `zc_exp` varchar(255) CHARACTER SET utf8 COLLATE utf8_unicode_ci NULL DEFAULT '0' COMMENT '注册赠送积分',
  `zc_vip` varchar(255) CHARACTER SET utf8 COLLATE utf8_unicode_ci NULL DEFAULT '0' COMMENT '注册赠送会员',
  `sign_money` varchar(255) CHARACTER SET utf8 COLLATE utf8_unicode_ci NULL DEFAULT '0' COMMENT '签到赠送金币',
  `sign_exp` varchar(255) CHARACTER SET utf8 COLLATE utf8_unicode_ci NULL DEFAULT '0' COMMENT '签到赠送积分',
  `sign_vip` varchar(255) CHARACTER SET utf8 COLLATE utf8_unicode_ci NULL DEFAULT '0' COMMENT '签到赠送会员',
  `invitation_money` varchar(255) CHARACTER SET utf8 COLLATE utf8_unicode_ci NULL DEFAULT '0' COMMENT '邀请人获得金币',
  `invitation_exp` varchar(255) CHARACTER SET utf8 COLLATE utf8_unicode_ci NULL DEFAULT '0' COMMENT '邀请人获得积分',
  `invitation_vip` varchar(255) CHARACTER SET utf8 COLLATE utf8_unicode_ci NULL DEFAULT '0' COMMENT '邀请人获得会员',
  `equipment_num` int(11) NULL DEFAULT 0 COMMENT '单设备注册上限0不限制',
  `is_login` varchar(255) CHARACTER SET utf8 COLLATE utf8_unicode_ci NULL DEFAULT '0' COMMENT '是否允许登录0允许1不',
  `is_regemailcode` varchar(255) CHARACTER SET utf8 COLLATE utf8_unicode_ci NULL DEFAULT '0' COMMENT '是否开启注册需要验证码0允许1不',
  `is_reg` varchar(255) CHARACTER SET utf8 COLLATE utf8_unicode_ci NULL DEFAULT '0' COMMENT '是否允许注册0允许1不',
  `is_state` varchar(255) CHARACTER SET utf8 COLLATE utf8_unicode_ci NULL DEFAULT '0' COMMENT '是否允许开启app0允许1不',
  `is_equipment` varchar(255) CHARACTER SET utf8 COLLATE utf8_unicode_ci NULL DEFAULT '0' COMMENT '是否允许新设备登录同一账号',
  `is_remoteLogin` varchar(255) CHARACTER SET utf8 COLLATE utf8_unicode_ci NULL DEFAULT '0' COMMENT '是否启用异地登陆发邮件',
  `grade` longtext CHARACTER SET utf8 COLLATE utf8_unicode_ci NULL COMMENT '等级划分',
  `is_sign` varchar(255) CHARACTER SET utf8 COLLATE utf8_unicode_ci NULL DEFAULT '0' COMMENT '启用签名0允许1不',
  `signkey` varchar(255) CHARACTER SET utf8 COLLATE utf8_unicode_ci NULL DEFAULT NULL COMMENT '签名key',
  `poststate` tinyint(1) NULL DEFAULT 0 COMMENT '发帖是否需要审核0需要1不要',
  `codetype` tinyint(1) NULL DEFAULT 0 COMMENT '验证码发送类型0邮箱1验证码',
  PRIMARY KEY (`appid`) USING BTREE
) ENGINE = MyISAM AUTO_INCREMENT = 10000 CHARACTER SET = utf8 COLLATE = utf8_unicode_ci ROW_FORMAT = DYNAMIC;

-- ----------------------------
-- Records of mr_app
-- ----------------------------

-- ----------------------------
-- Table structure for mr_appdownload
-- ----------------------------
DROP TABLE IF EXISTS `mr_appdownload`;
CREATE TABLE `mr_appdownload`  (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `site_title` varchar(255) CHARACTER SET utf8 COLLATE utf8_unicode_ci NULL DEFAULT NULL COMMENT '下载页标题',
  `site_keywords` text CHARACTER SET utf8 COLLATE utf8_unicode_ci NULL COMMENT '站点关键词',
  `site_description` text CHARACTER SET utf8 COLLATE utf8_unicode_ci NULL COMMENT '站点描述',
  `copyright_information` varchar(255) CHARACTER SET utf8 COLLATE utf8_unicode_ci NULL DEFAULT NULL COMMENT '版权信息',
  `filing_information` varchar(255) CHARACTER SET utf8 COLLATE utf8_unicode_ci NULL DEFAULT NULL COMMENT '备案信息',
  `template` varchar(255) CHARACTER SET utf8 COLLATE utf8_unicode_ci NULL DEFAULT NULL COMMENT '模板文件',
  `code` varchar(255) CHARACTER SET utf8 COLLATE utf8_unicode_ci NULL DEFAULT NULL,
  `appid` int(11) NULL DEFAULT NULL COMMENT 'appid',
  `pic1` varchar(255) CHARACTER SET utf8 COLLATE utf8_unicode_ci NULL DEFAULT NULL,
  `pic2` varchar(255) CHARACTER SET utf8 COLLATE utf8_unicode_ci NULL DEFAULT NULL,
  `pic3` varchar(255) CHARACTER SET utf8 COLLATE utf8_unicode_ci NULL DEFAULT NULL,
  `pic4` varchar(255) CHARACTER SET utf8 COLLATE utf8_unicode_ci NULL DEFAULT NULL,
  `pic5` varchar(255) CHARACTER SET utf8 COLLATE utf8_unicode_ci NULL DEFAULT NULL,
  PRIMARY KEY (`id`) USING BTREE
) ENGINE = MyISAM AUTO_INCREMENT = 1 CHARACTER SET = utf8 COLLATE = utf8_unicode_ci ROW_FORMAT = DYNAMIC;

-- ----------------------------
-- Records of mr_appdownload
-- ----------------------------

-- ----------------------------
-- Table structure for mr_appnotice
-- ----------------------------
DROP TABLE IF EXISTS `mr_appnotice`;
CREATE TABLE `mr_appnotice`  (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `title` varchar(255) CHARACTER SET utf8 COLLATE utf8_unicode_ci NULL DEFAULT NULL COMMENT '公告标题',
  `content` varchar(255) CHARACTER SET utf8 COLLATE utf8_unicode_ci NULL DEFAULT NULL COMMENT '公告内容',
  `time` datetime NULL DEFAULT NULL COMMENT '发布时间',
  `appid` int(11) NULL DEFAULT NULL COMMENT 'appid',
  `is_del` tinyint(1) NULL DEFAULT 0 COMMENT '0未删除1删除',
  PRIMARY KEY (`id`) USING BTREE
) ENGINE = MyISAM AUTO_INCREMENT = 1 CHARACTER SET = utf8 COLLATE = utf8_unicode_ci COMMENT = 'app公告' ROW_FORMAT = DYNAMIC;

-- ----------------------------
-- Records of mr_appnotice
-- ----------------------------

-- ----------------------------
-- Table structure for mr_appupdate
-- ----------------------------
DROP TABLE IF EXISTS `mr_appupdate`;
CREATE TABLE `mr_appupdate`  (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `appid` int(11) NULL DEFAULT NULL,
  `versioncode` varchar(255) CHARACTER SET utf8 COLLATE utf8_unicode_ci NULL DEFAULT '1.0' COMMENT '版本号',
  `content` longtext CHARACTER SET utf8 COLLATE utf8_unicode_ci NULL COMMENT '更新内容',
  `download` varchar(255) CHARACTER SET utf8 COLLATE utf8_unicode_ci NULL DEFAULT NULL COMMENT '下载地址',
  `time` datetime NULL DEFAULT NULL COMMENT '发布时间',
  `is_del` tinyint(1) NULL DEFAULT 0 COMMENT '0未删除1删除',
  PRIMARY KEY (`id`) USING BTREE
) ENGINE = MyISAM AUTO_INCREMENT = 1 CHARACTER SET = utf8 COLLATE = utf8_unicode_ci ROW_FORMAT = DYNAMIC;

-- ----------------------------
-- Records of mr_appupdate
-- ----------------------------

-- ----------------------------
-- Table structure for mr_article
-- ----------------------------
DROP TABLE IF EXISTS `mr_article`;
CREATE TABLE `mr_article`  (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `title` varchar(255) CHARACTER SET utf8 COLLATE utf8_unicode_ci NULL DEFAULT NULL COMMENT '文章标题',
  `content` longtext CHARACTER SET utf8 COLLATE utf8_unicode_ci NULL COMMENT '文章内容',
  `status` tinyint(255) NULL DEFAULT 0 COMMENT '状态0待审核1已审核(正常)2审核未通过3文章锁定',
  `userid` int(11) NULL DEFAULT NULL COMMENT '用户id',
  `appid` int(11) NULL DEFAULT NULL COMMENT 'appid',
  `plateid` int(11) NULL DEFAULT NULL COMMENT '板块id',
  `createtime` datetime NULL DEFAULT NULL COMMENT '创建时间',
  `updatetime` datetime NULL DEFAULT NULL COMMENT '最近更新时间',
  `ip` varchar(255) CHARACTER SET utf8 COLLATE utf8_unicode_ci NULL DEFAULT NULL COMMENT 'ip',
  `video_url` varchar(255) CHARACTER SET utf8 COLLATE utf8_unicode_ci NULL DEFAULT NULL COMMENT '视频链接',
  `video_cover` varchar(255) CHARACTER SET utf8 COLLATE utf8_unicode_ci NULL DEFAULT NULL COMMENT '视频封面',
  `pic_url` longtext CHARACTER SET utf8 COLLATE utf8_unicode_ci NULL COMMENT '图片链',
  `top` tinyint(255) NULL DEFAULT 0 COMMENT '置顶0不置顶1置顶',
  `popular` tinyint(1) NULL DEFAULT 0 COMMENT '是否热门0普通1热门',
  `is_type` tinyint(1) NULL DEFAULT 0 COMMENT '0图文帖子1视频帖子',
  `network_pictures` longtext COLLATE utf8_unicode_ci COMMENT '网络图片',
  `expand` longtext CHARACTER SET utf8 COLLATE utf8_unicode_ci NULL,
  `attachment` varchar(255) CHARACTER SET utf8 COLLATE utf8_unicode_ci NULL DEFAULT NULL COMMENT '附件',
  PRIMARY KEY (`id`) USING BTREE,
  INDEX `userid`(`userid`) USING BTREE,
  INDEX `appid`(`appid`) USING BTREE
) ENGINE = MyISAM AUTO_INCREMENT = 1 CHARACTER SET = utf8 COLLATE = utf8_unicode_ci ROW_FORMAT = DYNAMIC;

-- ----------------------------
-- Records of mr_article
-- ----------------------------

-- ----------------------------
-- Table structure for mr_comments
-- ----------------------------
DROP TABLE IF EXISTS `mr_comments`;
CREATE TABLE `mr_comments`  (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `parentid` int(11) NULL DEFAULT NULL COMMENT '父评论的id,如果不是对评论的回复,那么该值为0',
  `postid` int(11) NULL DEFAULT NULL COMMENT '帖子id',
  `content` text CHARACTER SET utf8 COLLATE utf8_unicode_ci NULL COMMENT '内容',
  `userid` int(11) NULL DEFAULT NULL COMMENT '用户id',
  `time` datetime NULL DEFAULT NULL COMMENT '时间',
  `appid` int(11) NULL DEFAULT NULL COMMENT 'appid',
  PRIMARY KEY (`id`) USING BTREE,
  INDEX `parentid`(`parentid`) USING BTREE,
  INDEX `postid`(`postid`) USING BTREE
) ENGINE = MyISAM AUTO_INCREMENT = 1 CHARACTER SET = utf8 COLLATE = utf8_unicode_ci ROW_FORMAT = DYNAMIC;

-- ----------------------------
-- Records of mr_comments
-- ----------------------------

-- ----------------------------
-- Table structure for mr_config
-- ----------------------------
DROP TABLE IF EXISTS `mr_config`;
CREATE TABLE `mr_config`  (
  `id` smallint(5) UNSIGNED NOT NULL AUTO_INCREMENT COMMENT '配置ID',
  `type` char(20) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NULL DEFAULT '' COMMENT '分类',
  `value` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NULL COMMENT '配置值',
  PRIMARY KEY (`id`) USING BTREE,
  INDEX `idx_system_config_type`(`type`) USING BTREE
) ENGINE = InnoDB AUTO_INCREMENT = 3 CHARACTER SET = utf8mb4 COLLATE = utf8mb4_general_ci COMMENT = '系统配置表' ROW_FORMAT = DYNAMIC;

-- ----------------------------
-- Records of mr_config
-- ----------------------------
INSERT INTO `mr_config` VALUES (1, 'email', '{\"typename\":\"email\",\"username\":\"\",\"password\":\"\",\"host\":\"smtp.qq.com\",\"port\":\"465\",\"subject\":\"默然云后台管理系统\"}');
INSERT INTO `mr_config` VALUES (2, 'phone', '{\"typename\":\"phone\",\"accessKeyId\":\"\",\"accessKeySecret\":\"\",\"SignName\":\"\",\"TemplateCode\":\"\",\"TemplateParam\":\"code\"}');

-- ----------------------------
-- Table structure for mr_expand
-- ----------------------------
DROP TABLE IF EXISTS `mr_expand`;
CREATE TABLE `mr_expand`  (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `title` varchar(255) CHARACTER SET utf8 COLLATE utf8_unicode_ci NULL DEFAULT NULL COMMENT '名称',
  `content` longtext CHARACTER SET utf8 COLLATE utf8_unicode_ci NULL,
  `icon` varchar(255) CHARACTER SET utf8 COLLATE utf8_unicode_ci NULL DEFAULT NULL COMMENT '图标',
  `satus` int(11) NULL DEFAULT NULL COMMENT '状态',
  `creattime` datetime NULL DEFAULT NULL COMMENT '创建时间',
  `appid` int(11) NULL DEFAULT NULL,
  `userid` int(11) NULL DEFAULT NULL,
  PRIMARY KEY (`id`) USING BTREE
) ENGINE = MyISAM AUTO_INCREMENT = 1 CHARACTER SET = utf8 COLLATE = utf8_unicode_ci ROW_FORMAT = Dynamic;

-- ----------------------------
-- Records of mr_expand
-- ----------------------------

-- ----------------------------
-- Table structure for mr_follow
-- ----------------------------
DROP TABLE IF EXISTS `mr_follow`;
CREATE TABLE `mr_follow`  (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `userid` int(11) NULL DEFAULT NULL COMMENT '用户id',
  `followedid` int(11) NULL DEFAULT NULL COMMENT '关注的用户ID',
  `create_time` datetime NULL DEFAULT NULL COMMENT '创建时间',
  `appid` int(11) NULL DEFAULT NULL COMMENT 'appid',
  PRIMARY KEY (`id`) USING BTREE,
  INDEX `userid`(`userid`) USING BTREE,
  INDEX `followedid`(`followedid`) USING BTREE
) ENGINE = MyISAM AUTO_INCREMENT = 1 CHARACTER SET = utf8 COLLATE = utf8_unicode_ci COMMENT = '关注表' ROW_FORMAT = FIXED;

-- ----------------------------
-- Records of mr_follow
-- ----------------------------

-- ----------------------------
-- Table structure for mr_invitation
-- ----------------------------
DROP TABLE IF EXISTS `mr_invitation`;
CREATE TABLE `mr_invitation`  (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `userid` int(11) NULL DEFAULT NULL COMMENT '邀请人  用户id',
  `newuserid` int(11) NULL DEFAULT NULL COMMENT '被邀请  用户id',
  `appid` int(11) NULL DEFAULT NULL COMMENT 'appid',
  `createtime` datetime NULL DEFAULT NULL COMMENT '邀请时间',
  PRIMARY KEY (`id`) USING BTREE,
  INDEX `newuserid`(`newuserid`) USING BTREE
) ENGINE = MyISAM AUTO_INCREMENT = 1 CHARACTER SET = utf8 COLLATE = utf8_unicode_ci ROW_FORMAT = FIXED;

-- ----------------------------
-- Records of mr_invitation
-- ----------------------------

-- ----------------------------
-- Table structure for mr_km
-- ----------------------------
DROP TABLE IF EXISTS `mr_km`;
CREATE TABLE `mr_km`  (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `km` varchar(255) CHARACTER SET utf8 COLLATE utf8_unicode_ci NULL DEFAULT NULL,
  `exp` varchar(255) CHARACTER SET utf8 COLLATE utf8_unicode_ci NULL DEFAULT NULL COMMENT '经验',
  `money` varchar(255) CHARACTER SET utf8 COLLATE utf8_unicode_ci NULL DEFAULT NULL COMMENT '金币',
  `viptime` varchar(255) CHARACTER SET utf8 COLLATE utf8_unicode_ci NULL DEFAULT NULL COMMENT '会员天数',
  `device` varchar(255) CHARACTER SET utf8 COLLATE utf8_unicode_ci NULL DEFAULT NULL COMMENT '设备号',
  `expire` varchar(255) CHARACTER SET utf8 COLLATE utf8_unicode_ci NULL DEFAULT NULL COMMENT '过期时间',
  `state` tinyint(1) NULL DEFAULT 0 COMMENT '0未使用1已使用',
  `type` tinyint(1) NULL DEFAULT 0 COMMENT '0直充类1登录',
  `username` varchar(255) CHARACTER SET utf8 COLLATE utf8_unicode_ci NULL DEFAULT NULL COMMENT '使用者',
  `usetime` datetime NULL DEFAULT NULL COMMENT '使用时间',
  `appid` int(11) NULL DEFAULT NULL COMMENT 'appid',
  `classification` varchar(255) CHARACTER SET utf8 COLLATE utf8_unicode_ci NULL DEFAULT NULL COMMENT '分类',
  `creattime` datetime NULL DEFAULT NULL COMMENT '创建时间',
  PRIMARY KEY (`id`) USING BTREE
) ENGINE = MyISAM AUTO_INCREMENT = 1 CHARACTER SET = utf8 COLLATE = utf8_unicode_ci ROW_FORMAT = DYNAMIC;

-- ----------------------------
-- Records of mr_km
-- ----------------------------

-- ----------------------------
-- Table structure for mr_message
-- ----------------------------
DROP TABLE IF EXISTS `mr_message`;
CREATE TABLE `mr_message`  (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `title` varchar(255) CHARACTER SET utf8 COLLATE utf8_unicode_ci NULL DEFAULT NULL COMMENT '标题',
  `content` text CHARACTER SET utf8 COLLATE utf8_unicode_ci NULL COMMENT '内容',
  `sender_id` int(11) NULL DEFAULT 0 COMMENT '发送者id,0为管理员',
  `appid` int(11) NULL DEFAULT NULL COMMENT 'appid',
  `type` tinyint(1) NULL DEFAULT 0 COMMENT '类型0系统消息1点赞消息2评论消息',
  `time` datetime NULL DEFAULT NULL COMMENT '通知时间',
  `postid` int(11) NULL DEFAULT NULL COMMENT '帖子id',
  PRIMARY KEY (`id`) USING BTREE
) ENGINE = MyISAM AUTO_INCREMENT = 1 CHARACTER SET = utf8 COLLATE = utf8_unicode_ci ROW_FORMAT = DYNAMIC;

-- ----------------------------
-- Records of mr_message
-- ----------------------------

-- ----------------------------
-- Table structure for mr_message_user
-- ----------------------------
DROP TABLE IF EXISTS `mr_message_user`;
CREATE TABLE `mr_message_user`  (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `msg_id` int(11) NULL DEFAULT NULL COMMENT '消息id',
  `user_id` int(11) NULL DEFAULT NULL COMMENT '通知用户id',
  `state` tinyint(1) NULL DEFAULT 0 COMMENT '0未读1已读',
  `appid` int(11) NULL DEFAULT NULL,
  PRIMARY KEY (`id`) USING BTREE,
  INDEX `msg_id`(`msg_id`) USING BTREE,
  INDEX `user_id`(`user_id`) USING BTREE,
  INDEX `appid`(`appid`) USING BTREE
) ENGINE = MyISAM AUTO_INCREMENT = 1 CHARACTER SET = utf8 COLLATE = utf8_unicode_ci ROW_FORMAT = FIXED;

-- ----------------------------
-- Records of mr_message_user
-- ----------------------------

-- ----------------------------
-- Table structure for mr_notes
-- ----------------------------
DROP TABLE IF EXISTS `mr_notes`;
CREATE TABLE `mr_notes`  (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `title` varchar(255) CHARACTER SET utf8 COLLATE utf8_unicode_ci NULL DEFAULT NULL COMMENT '笔记标题',
  `content` longtext CHARACTER SET utf8 COLLATE utf8_unicode_ci NULL COMMENT '笔记内容',
  `ip` varchar(255) CHARACTER SET utf8 COLLATE utf8_unicode_ci NULL DEFAULT NULL COMMENT 'ip',
  `creattime` datetime NULL DEFAULT NULL COMMENT '创建时间',
  `updatetime` datetime NULL DEFAULT NULL COMMENT '修改时间',
  `appid` int(11) NULL DEFAULT NULL COMMENT 'appid',
  `user_id` int(11) NULL DEFAULT NULL COMMENT 'user_id',
  PRIMARY KEY (`id`) USING BTREE,
  INDEX `user_id`(`user_id`) USING BTREE
) ENGINE = MyISAM AUTO_INCREMENT = 1 CHARACTER SET = utf8 COLLATE = utf8_unicode_ci ROW_FORMAT = DYNAMIC;

-- ----------------------------
-- Records of mr_notes
-- ----------------------------

-- ----------------------------
-- Table structure for mr_order
-- ----------------------------
DROP TABLE IF EXISTS `mr_order`;
CREATE TABLE `mr_order`  (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `order_no` varchar(255) CHARACTER SET utf8 COLLATE utf8_unicode_ci NULL DEFAULT NULL COMMENT '订单号',
  `shop_id` int(11) NULL DEFAULT NULL COMMENT '商品id',
  `transaction_no` varchar(255) CHARACTER SET utf8 COLLATE utf8_unicode_ci NULL DEFAULT NULL COMMENT '交易号',
  `userid` int(11) NULL DEFAULT NULL COMMENT '用户id',
  `status` tinyint(1) NULL DEFAULT 0 COMMENT '0待付款1已付款',
  `paymenttime` datetime NULL DEFAULT NULL COMMENT '支付时间',
  `createtime` datetime NULL DEFAULT NULL COMMENT '创建时间',
  `appid` int(11) NULL DEFAULT NULL,
  `price` varchar(255) CHARACTER SET utf8 COLLATE utf8_unicode_ci NULL DEFAULT NULL COMMENT '价格',
  PRIMARY KEY (`id`) USING BTREE,
  INDEX `userid`(`userid`) USING BTREE
) ENGINE = MyISAM AUTO_INCREMENT = 1 CHARACTER SET = utf8 COLLATE = utf8_unicode_ci ROW_FORMAT = DYNAMIC;

-- ----------------------------
-- Records of mr_order
-- ----------------------------

-- ----------------------------
-- Table structure for mr_payment
-- ----------------------------
DROP TABLE IF EXISTS `mr_payment`;
CREATE TABLE `mr_payment`  (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `pay_url` varchar(255) CHARACTER SET utf8 COLLATE utf8_unicode_ci NOT NULL COMMENT '请求地址',
  `public_key` text CHARACTER SET utf8 COLLATE utf8_unicode_ci NULL COMMENT '公钥',
  `private_key` text CHARACTER SET utf8 COLLATE utf8_unicode_ci NULL COMMENT '商户私钥',
  `appid` varchar(255) CHARACTER SET utf8 COLLATE utf8_unicode_ci NULL DEFAULT NULL COMMENT '应用id',
  `name` varchar(255) CHARACTER SET utf8 COLLATE utf8_unicode_ci NULL DEFAULT NULL COMMENT '支付名称',
  `class_name` varchar(255) CHARACTER SET utf8 COLLATE utf8_unicode_ci NULL DEFAULT NULL COMMENT '支付类名称',
  `payment_id` tinyint(4) NULL DEFAULT NULL COMMENT '对应支付的id',
  PRIMARY KEY (`id`) USING BTREE
) ENGINE = MyISAM AUTO_INCREMENT = 3 CHARACTER SET = utf8 COLLATE = utf8_unicode_ci ROW_FORMAT = DYNAMIC;

-- ----------------------------
-- Records of mr_payment
-- ----------------------------
INSERT INTO `mr_payment` VALUES (1, 'https://openapi.alipay.com/gateway.do', '', '', '', '支付宝当面付', 'Alipay', 0);
INSERT INTO `mr_payment` VALUES (2, '', NULL, NULL, NULL, '源支付', 'Ypay', 3);
INSERT INTO `mr_payment` VALUES (3, '', '', '', '', '易支付', 'Yipay', 4);

-- ----------------------------
-- Table structure for mr_plate
-- ----------------------------
DROP TABLE IF EXISTS `mr_plate`;
CREATE TABLE `mr_plate`  (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `platename` varchar(255) CHARACTER SET utf8 COLLATE utf8_unicode_ci NULL DEFAULT NULL COMMENT '板块名称',
  `plateicon` varchar(255) CHARACTER SET utf8 COLLATE utf8_unicode_ci NULL DEFAULT NULL COMMENT '板块图标',
  `satus` tinyint(1) NULL DEFAULT NULL COMMENT '状态0只允许管理员发帖1允许全部用户发帖',
  `creattime` datetime NULL DEFAULT NULL COMMENT '创建时间',
  `appid` int(11) NULL DEFAULT NULL,
  `admin` varchar(255) CHARACTER SET utf8 COLLATE utf8_unicode_ci NULL DEFAULT NULL COMMENT '管理员',
  `plateontent` varchar(255) CHARACTER SET utf8 COLLATE utf8_unicode_ci NULL DEFAULT NULL COMMENT '板块描述',
  `plategg` varchar(255) CHARACTER SET utf8 COLLATE utf8_unicode_ci NULL DEFAULT NULL COMMENT '板块公告',
  PRIMARY KEY (`id`) USING BTREE
) ENGINE = MyISAM AUTO_INCREMENT = 1 CHARACTER SET = utf8 COLLATE = utf8_unicode_ci ROW_FORMAT = DYNAMIC;

-- ----------------------------
-- Records of mr_plate
-- ----------------------------

-- ----------------------------
-- Table structure for mr_shop
-- ----------------------------
DROP TABLE IF EXISTS `mr_shop`;
CREATE TABLE `mr_shop`  (
  `id` int(11) NOT NULL AUTO_INCREMENT COMMENT 'Id',
  `name` varchar(255) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL COMMENT '商品名称',
  `subimages` varchar(255) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL COMMENT '产品主图,url相对地址',
  `detail` varchar(255) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL COMMENT '商品详情',
  `price` varchar(255) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL COMMENT '价格',
  `stock` int(11) NULL DEFAULT NULL COMMENT '库存数量',
  `createtime` datetime NULL DEFAULT NULL COMMENT '创建时间',
  `payment` tinyint(255) NULL DEFAULT NULL COMMENT '支付方式0支付宝1金币2积分',
  `type` varchar(255) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL COMMENT '商品类型0兑换会员1其他',
  `content` longtext CHARACTER SET utf8 COLLATE utf8_general_ci NULL COMMENT '商品类型为0时填写天数为1时填写json内容',
  `appid` int(11) NULL DEFAULT NULL,
  PRIMARY KEY (`id`) USING BTREE
) ENGINE = InnoDB AUTO_INCREMENT = 1 CHARACTER SET = utf8 COLLATE = utf8_general_ci ROW_FORMAT = DYNAMIC;

-- ----------------------------
-- Records of mr_shop
-- ----------------------------

-- ----------------------------
-- Table structure for mr_sign
-- ----------------------------
DROP TABLE IF EXISTS `mr_sign`;
CREATE TABLE `mr_sign`  (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `userid` int(11) NULL DEFAULT NULL COMMENT '用户id',
  `lasttime` int(11) NULL DEFAULT NULL COMMENT '最后一次签到时间',
  `series_days` int(11) NULL DEFAULT 0 COMMENT '累计签到天数',
  `continuity_days` int(11) NULL DEFAULT 0 COMMENT '连续签到天数',
  `appid` int(11) NULL DEFAULT NULL COMMENT 'appid',
  PRIMARY KEY (`id`) USING BTREE,
  INDEX `userid`(`userid`) USING BTREE
) ENGINE = MyISAM AUTO_INCREMENT = 1 CHARACTER SET = utf8 COLLATE = utf8_unicode_ci ROW_FORMAT = FIXED;

-- ----------------------------
-- Records of mr_sign
-- ----------------------------

-- ----------------------------
-- Table structure for mr_user
-- ----------------------------
DROP TABLE IF EXISTS `mr_user`;
CREATE TABLE `mr_user`  (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `appid` int(11) NULL DEFAULT NULL COMMENT 'appid',
  `username` varchar(255) CHARACTER SET utf8 COLLATE utf8_unicode_ci NULL DEFAULT NULL COMMENT '用户名',
  `password` varchar(255) CHARACTER SET utf8 COLLATE utf8_unicode_ci NULL DEFAULT NULL COMMENT '密码',
  `salt` varchar(255) CHARACTER SET utf8 COLLATE utf8_unicode_ci NULL DEFAULT NULL COMMENT '密码盐',
  `usertx` varchar(255) CHARACTER SET utf8 COLLATE utf8_unicode_ci NULL DEFAULT '/user.png' COMMENT '头像',
  `nickname` varchar(255) CHARACTER SET utf8 COLLATE utf8_unicode_ci NULL DEFAULT '这个人暂未设置昵称' COMMENT '昵称',
  `money` int(255) NULL DEFAULT 0 COMMENT '金币',
  `exp` int(255) NULL DEFAULT 0 COMMENT '经验',
  `viptime` varchar(255) CHARACTER SET utf8 COLLATE utf8_unicode_ci NULL DEFAULT NULL COMMENT '会员时间戳',
  `sex` tinyint(255) NULL DEFAULT 0 COMMENT '0男1女',
  `qq` varchar(255) CHARACTER SET utf8 COLLATE utf8_unicode_ci NULL DEFAULT NULL COMMENT 'qq',
  `useremail` varchar(255) CHARACTER SET utf8 COLLATE utf8_unicode_ci NULL DEFAULT NULL COMMENT '邮箱',
  `signature` varchar(255) CHARACTER SET utf8 COLLATE utf8_unicode_ci NULL DEFAULT NULL COMMENT '个性签名',
  `title` varchar(255) CHARACTER SET utf8 COLLATE utf8_unicode_ci NULL DEFAULT NULL COMMENT '头衔',
  `invitecode` varchar(255) CHARACTER SET utf8 COLLATE utf8_unicode_ci NULL DEFAULT NULL COMMENT '邀请码',
  `login_device` varchar(255) CHARACTER SET utf8 COLLATE utf8_unicode_ci NULL DEFAULT NULL COMMENT '登录设备码',
  `register_device` varchar(255) CHARACTER SET utf8 COLLATE utf8_unicode_ci NULL DEFAULT NULL COMMENT '注册的设备码',
  `reasons` tinyint(1) NULL DEFAULT 0 COMMENT '状态0正常1封禁',
  `reasons_ban` varchar(255) CHARACTER SET utf8 COLLATE utf8_unicode_ci NULL DEFAULT NULL COMMENT '封禁理由',
  `create_time` datetime NULL DEFAULT NULL COMMENT '创建时间',
  `ip` varchar(255) CHARACTER SET utf8 COLLATE utf8_unicode_ci NULL DEFAULT NULL COMMENT '登录ip',
  `usertoken` varchar(255) CHARACTER SET utf8 COLLATE utf8_unicode_ci NULL DEFAULT NULL COMMENT '验证作用',
  `userbg` varchar(255) CHARACTER SET utf8 COLLATE utf8_unicode_ci NULL DEFAULT '/userbg.jpg' COMMENT '背景',
  `phone` varchar(255) CHARACTER SET utf8 COLLATE utf8_unicode_ci NULL DEFAULT NULL COMMENT '手机号',
  PRIMARY KEY (`id`) USING BTREE,
  INDEX `appid`(`appid`) USING BTREE
) ENGINE = MyISAM AUTO_INCREMENT = 1 CHARACTER SET = utf8 COLLATE = utf8_unicode_ci ROW_FORMAT = DYNAMIC;

-- ----------------------------
-- Records of mr_user
-- ----------------------------

-- ----------------------------
-- Table structure for mr_view
-- ----------------------------
DROP TABLE IF EXISTS `mr_view`;
CREATE TABLE `mr_view`  (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `appid` int(11) NULL DEFAULT NULL,
  `time` datetime NULL DEFAULT NULL COMMENT '创建时间',
  `userid` int(11) NULL DEFAULT NULL COMMENT '用户id',
  `postid` int(11) NULL DEFAULT NULL COMMENT '帖子id',
  `type` tinyint(1) NULL DEFAULT 0 COMMENT '类型0app访问量1帖子访问量2点赞',
  PRIMARY KEY (`id`) USING BTREE,
  INDEX `userid`(`userid`) USING BTREE,
  INDEX `appid`(`appid`) USING BTREE
) ENGINE = MyISAM AUTO_INCREMENT = 1 CHARACTER SET = utf8 COLLATE = utf8_unicode_ci ROW_FORMAT = FIXED;

-- ----------------------------
-- Records of mr_view
-- ----------------------------

SET FOREIGN_KEY_CHECKS = 1;
