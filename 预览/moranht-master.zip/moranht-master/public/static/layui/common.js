$(document).ready(function () {
    $(document).on('click', '.file-browser', function () {
        var $browser = $(this);
        var file = $browser.closest('.file-group').find('[type="file"]');
        file.on('click', function (e) {
            e.stopPropagation();
        });
        file.trigger('click');
    });

    $(document).on('change', '.file-group [type="file"]', function () {
        var $this = $(this);
        var $input = $(this)[0];
        var $len = $input.files.length;
        var formFile = new FormData();

        if ($len == 0) {
            return false;
        } else {
            var fileAccaccept = $this.attr('accaccept');
            var fileType = $input.files[0].type;
            var type = (fileType.substr(fileType.lastIndexOf("/") + 1)).toLowerCase();

            if (!type || fileAccaccept.indexOf(type) == -1) {
                notify.error('您上传图片的类型不符合'+fileAccaccept);
                return false;
            }
            formFile.append("file", $input.files[0]);
        }

        var data = formFile;
        var l = $('body').lyearloading({
            opacity: 0.2,
            spinnerSize: 'lg'
        });
        $.ajax({
            url: '/admin/index/upload',
            data: data,
            type: "POST",
            dataType: "json",
            //上传文件无需缓存
            cache: false,
            //用于对data参数进行序列化处理 这里必须false
            processData: false,
            //必须
            contentType: false,
            success: function (res) {
                l.destroy();
                if (res.code === 200) {
                    notify.success("上传成功");
                    $this.closest('.file-group').find('.file-value').val(res.data.filePath);
                } else {
                    notify.error(res.msg);
                }
            },
            error:function(){
                l.destroy();
                notify.error("服务器错误");
            }
        });
    });
});

$.fn.ghostsf_serialize = function () {
    var a = this.serializeArray();
    var $radio = $('input[type=radio],input[type=checkbox]', this);
    $.each($radio, function () {
        if ($("input[name='" + this.name + "']").is(':checked')) {
            console.log(this.name + " is checked!");
            for (var k = 0; k < a.length; k++) {
                if (a[k].name == this.name) {
                    a[k].value = true;
                    break;
                }
            }
        } else {
            var find = false;
            for (var k = 0; k < a.length; k++) {
                if (a[k].name == this.name) {
                    a[k].value = false;
                    find = true;
                    break;
                }
            }
            if (!find) {
                a.push({ name: this.name, value: false });
            }
        }

    });
    var $num = $('input[type=number]', this);
    $.each($num, function () {
        for (var k = 0; k < a.length; k++) {
            if (a[k].name == this.name) {
                a[k].value = Number(a[k].value);
                break;
            }
        }
    });

    return a;
};

$.fn.parseForm = function () {
    let serializeObj = {};
    let array = this.ghostsf_serialize();
    let str = this.serialize();
    $(array).each(function () {
        if (serializeObj[this.name]) {
            if ($.isArray(serializeObj[this.name])) {
                serializeObj[this.name].push(this.value);
            } else {
                serializeObj[this.name] = [serializeObj[this.name], this.value];
            }
        } else {
            serializeObj[this.name] = this.value;
        }
    });
    return serializeObj;
};

function randomString(length) {
    var chars = "0123456789abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ";
    var result = '';
    for (var i = length; i > 0; --i) result += chars[Math.floor(Math.random() * chars.length)];
    return result;
}