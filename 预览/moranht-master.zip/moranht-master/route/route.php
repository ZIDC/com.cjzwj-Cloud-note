<?php

use think\facade\Route;

Route::rule('api/:action','api/api/:action');

Route::get('code/:code', 'index/code');

Route::get('post/:id', 'index/querypost');

Route::get('notes/:id', 'index/querynotes');