<?php

return [
    \app\http\middleware\AdminAuth::class,
];
