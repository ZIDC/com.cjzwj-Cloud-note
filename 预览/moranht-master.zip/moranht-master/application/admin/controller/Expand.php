<?php

namespace app\admin\controller;

use think\Db;

class Expand extends Base
{
    public function index()
    {
        $res = Db::name("expand")->paginate(10);
        $this->assign("res",$res);
        return $this->fetch();
    }

    public function edit()
    {
        $type = input('?type') ? input('type') : 0;
        if($type == 1){
            $id = input('id');
            if($id == ""){
                $this->error("系统错误");
            }
            $res = Db::name("expand")->where("id",$id)->find();
            $this->assign("data",$res);
        }
        $this->assign("type",$type);
        return $this->fetch();
    }

    public function edit_do()
    {
        $data = input();
        if($data["id"] == ""){
            //新增
            unset($data["id"]);
            $data["creattime"] = date("Y-m-d H:i:s",time());
            $res = Db::name('expand')->insert($data);
            if($res == 1){
                return $this->success("新增成功","expand/index");
            }else{
                return $this->error("系统错误");
            }
        }else{
            $id = $data["id"];
            unset($data["id"]);
            Db::name('expand')->where('id', $id)->update($data);
            $this->success("修改成功");
        }
    }

    public function delete()
    {
        $id = input('id');
        if($id == ""){
            $this->error("系统错误");
        }
        Db::name('expand')->where('id',$id)->delete();
        $this->success("删除成功");
    }
}