<?php

namespace app\admin\controller;

use app\admin\service\Aliphone;
use app\admin\service\Mail;
use app\admin\service\MailSendingTemplate;

class System extends Base
{
    public function email()
    {
        if (request()->isAjax()) {
            $data = input();
            $rs["type"] = "email";
            $rs["data"] = json_encode($data,JSON_UNESCAPED_UNICODE);
            $result = model("system")->edit($rs);
            if ($result == 1) {
                return $this->success("修改成功");
            } else {
                return $this->error($result);
            }
        } else {
            $result = model("system")->getValueBytype("email");
            $this->assign("email", $result);
            return $this->fetch();
        }
    }

    public function TestEmail()
    {
        $addAddress = input('test_email');
        return Mail::sendEmail('',$addAddress,"",MailSendingTemplate::testemail());
    }

    public function phone()
    {
        if (request()->isAjax()) {
            $data = input();
            $rs["type"] = "phone";
            $rs["data"] = json_encode($data,JSON_UNESCAPED_UNICODE);
            $result = model("system")->edit($rs);
            if ($result == 1) {
                return $this->success("修改成功");
            } else {
                return $this->error($result);
            }
        } else {
            $result = model("system")->getValueBytype("phone");
            $this->assign("phone", $result);
            return $this->fetch();
        }
    }

    public function Testphone()
    {
        $phone = input('PhoneNumbers');
        $code = rand(100000,999999);
        $result = Aliphone::sendPhone($phone,$code);
        $result = json_decode($result,true);
        if(isset($result["code"]) && $result["code"] == 200){
            if($result["data"]["body"]["code"] == "OK"){
                echo $this->success("发送成功");
            }else{
                echo $this->error($result["data"]["body"]["message"]);
            }
        }else{
            echo $this->error($result["data"]);
        }
    }
}
