<?php

namespace app\admin\controller;

class App extends Base
{
    public function index()
    {
        return $this->fetch();
    }

    //获取所有app
    public function getAllApps()
    {
        $data = [
            "sort" => input('?sort') ? input('sort') : 'appid',
            "sortOrder" => input("?sortOrder") ? input("sortOrder") : "asc",
            "appname" => input("appname"),
            "limit" => input('limit')?input('limit'):10,
            "page" => input('page')?input('page'):1,
        ];
        $result = model("app")->getAllApps($data);
        return $result;
    }

    public function add()
    {
        $data = [
            "appname" => input("post.appname"),
        ];
        $result = model("app")->add($data);
        if ($result == 1) {
            return $this->success("添加成功");
        } else {
            return $this->error($result);
        }
    }

    //统计访问量
    public function count($appid)
    {
        $count = model("view")->countview($appid);
        return $count;
    }

    public function editstatus()
    {
        $appid = explode(",", input('appid'));
        $appstate = input("appstate");
        $result = model("app")->editstatus($appid, $appstate);
        if ($result == 1) {
            return $this->success("修改成功");
        } else {
            return $this->error($result);
        }
    }

    public function delete()
    {
        $appid = explode(",", input('appid'));
        $result = model("app")->deleteapp($appid);
        if ($result == 1) {
            return $this->success("删除成功");
        } else {
            return $this->error($result);
        }
    }

    public function edit()
    {
        if (request()->isAjax()) {
            $data = input();
            if (!isset($data["is_login"])) {
                $data["is_login"] = 1;
            } else {
                $data["is_login"] = 0;
            }
            if (!isset($data["is_reg"])) {
                $data["is_reg"] = 1;
            } else {
                $data["is_reg"] = 0;
            }
            if (!isset($data["is_regemailcode"])) {
                $data["is_regemailcode"] = 1;
            } else {
                $data["is_regemailcode"] = 0;
            }
            if (!isset($data["is_equipment"])) {
                $data["is_equipment"] = 1;
            } else {
                $data["is_equipment"] = 0;
            }
            if (!isset($data["is_remoteLogin"])) {
                $data["is_remoteLogin"] = 1;
            } else {
                $data["is_remoteLogin"] = 0;
            }
            if (!isset($data["is_sign"])) {
                $data["is_sign"] = 1;
                $data["signkey"] = "";
            } else {
                $data["is_sign"] = 0;
            }
            if (!isset($data["is_state"])) {
                $data["is_state"] = 1;
            } else {
                $data["is_state"] = 0;
            }
            if (!isset($data["poststate"])) {
                $data["poststate"] = 1;
            } else {
                $data["poststate"] = 0;
            }
            $result = model("app")->edit($data);
            if ($result == 1) {
                return $this->success("修改成功");
            } else {
                return $this->error($result);
            }
        } else {
            $appid = input("appid");
            if ($appid == "") {
                $this->error("服务器错误");
            }
            $result = model("app")->getappinfo($appid);
            if ($result == null) {
                $this->error("服务器错误");
            }
            $this->assign("appinfo", $result);
            return $this->fetch();
        }
    }

    //消息页面
    public function messages()
    {
        $result = model("message")->getmessagelist();
        $this->assign("data", $result);
        return $this->fetch('message');
    }

    //消息页面
    public function addmessages()
    {
        $data = [
            "title" => input("post.title"),
            "content" => input("post.content"),
            "appid" => input("post.appid"),
        ];
        if($data["title"] == "" || $data["content"] == "" || $data["appid"] == ""){
            return $this->error("请填写完整");
        }
        $result = model("message")->add($data);
        if($result == 1){
            return $this->success("添加成功");
        }else{
            return $this->error("服务器错误");
        }
    }

    public function deletemsg()
    {
        $id = input("post.id");
        if(empty($id)){
            return $this->error("服务器错误");
        }
        $result = model("message")->delmsg($id);
        if($result == 1){
            return $this->success("删除成功");
        }else{
            return $this->error("服务器错误");
        }
    }
}
