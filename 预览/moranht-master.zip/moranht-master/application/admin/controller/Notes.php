<?php

namespace app\admin\controller;

class Notes extends Base
{
    public function index()
    {
        return $this->fetch();
    }

    public function Getnoteslist()
    {
        $data = [
            "sort" => input('sort')?input('sort'):'id',
            "sortOrder" => input('sortOrder')?input('sortOrder'):'desc',
            "title" => input('title'),
            "limit" => input('limit')?input('limit'):10,
            "page" => input('page')?input('page'):1,
        ];
        $result = model("notes")->Getnoteslist($data);
        return $result;
    }

    public function delete()
    {
        $id = explode(",", input('id'));
        $result = model("notes")->deletenotes($id);
        if ($result == 1) {
            return $this->success("删除成功");
        } else {
            return $this->error($result);
        }
    }

    public function edit()
    {
        if (request()->isAjax()) {
            $data = input();
            $result = model("notes")->edit($data);
            if ($result == 1) {
                return $this->success("修改成功");
            } else {
                return $this->error($result);
            }
        } else {
            $id = input("id");
            if ($id == "") {
                $this->error("服务器错误");
            }
            $result = model("notes")->getappinfo($id);
            if ($result == null) {
                $this->error("服务器错误");
            }
            $this->assign("notes", $result);
            return $this->fetch();
        }
    }

}