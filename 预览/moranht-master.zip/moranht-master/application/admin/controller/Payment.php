<?php

namespace app\admin\controller;

class Payment extends Base
{
    public function index()
    {
        $result = model("payment")->getpaymentlist();
        $this->assign("data", $result);
        return $this->fetch();
    }

    public function edit()
    {
        if (request()->isAjax()) {
            $data = input();
            $result = model("payment")->edit($data);
            if ($result == 1) {
                return $this->success("修改成功");
            } else {
                return $this->error($result);
            }
        } else {
            $id = input("id");
            if ($id == "") {
                $this->error("服务器错误");
            }
            $result = model("payment")->getpaymentinfo($id);
            if ($result == null) {
                $this->error("服务器错误");
            }
            $this->assign("data", $result);
            return $this->fetch();
        }
    }
}
