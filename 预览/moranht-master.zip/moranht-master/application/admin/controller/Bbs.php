<?php

namespace app\admin\controller;

use think\Db;

class Bbs extends Base
{
    public function plate()
    {
        return $this->fetch();
    }

    public function getplatelist()
    {
        $data = [
            "sort" => input('?sort') ? input('sort') : 'id',
            "sortOrder" => input("?sortOrder") ? input("sortOrder") : "asc",
            "platename" => input("platename"),
            "limit" => input('limit')?input('limit'):10,
            "page" => input('page')?input('page'):1,
        ];
        $result = model("plate")->getplatelist($data);
        return $result;
    }

    public function addplate()
    {
        $data = input();
        $result = model("plate")->addplate($data);
        if($result == 1){
            return $this->success("添加成功");
        }else{
            return $this->error($result);
        }
    }

    public function editplate()
    {
        if (request()->isAjax()) {
            $data = input();
            $result = model("plate")->editplate($data);
            if ($result == 1) {
                return $this->success("修改成功");
            } else {
                return $this->error($result);
            }
        } else {
            $id = input("id");
            if ($id == "") {
                $this->error("服务器错误");
            }
            $result = model("plate")->getplateinfo($id);
            if ($result == null) {
                $this->error("服务器错误");
            }
            $this->assign("plate", $result);
            return $this->fetch();
        }
    }

    public function deleteplate()
    {
        $id = explode(",", input('id'));
        $result = model("plate")->deleteplate($id);
        if ($result == 1) {
            return $this->success("删除成功");
        } else {
            return $this->error($result);
        }
    }

    // 帖子模块
    public function post()
    {
        return $this->fetch();
    }

    public function getpostlist()
    {
        $data = [
            "sort" => input('?sort') ? input('sort') : 'id',
            "sortOrder" => input("?sortOrder") ? input("sortOrder") : "asc",
            "postname" => input("postname"),
            "appid" => input("appid"),
            "plateid" => input("plateid"),
            "limit" => input('limit')?input('limit'):10,
            "page" => input('page')?input('page'):1,
        ];
        $where = " p.id > 0 ";
        if($data["postname"] != ""){
            $where .= " p.postname like '%".$data['postname']."%'";
        }
        if($data["appid"] != ""){
            $where .= " and p.appid = {$data['appid']}";
        }
        if($data["plateid"] != ""){
            $where .= " and p.plateid = {$data['plateid']}";
        }
        $data["where"] = $where;
        $result = model("article")->getpostlist($data);
        return $result;
    }

    public function deletepost()
    {
        $id = explode(",", input('id'));
        $result = model("article")->deletepost($id);
        if ($result == 1) {
            return $this->success("删除成功");
        } else {
            return $this->error($result);
        }
    }

    public function editpost()
    {
        if (request()->isAjax()) {
            $data = input();
            $result = model("article")->editarticle($data);
            if ($result == 1) {
                return $this->success("修改成功");
            } else {
                return $this->error($result);
            }
        } else {
            $id = input("id");
            if ($id == "") {
                $this->error("服务器错误");
            }
            $result = model("article")->getarticleinfo($id);
            if ($result == null) {
                $this->error("服务器错误");
            }
            $this->assign("article", $result);
            $this->assign("show", 1);
            return $this->fetch();
        }
    }

    public function addpost()
    {
        if (request()->isAjax()) {
            $data = input();
            $result = model("article")->addarticle($data);
            if ($result == 1) {
                return $this->success("添加成功");
            } else {
                return $this->error($result);
            }
        } else {
            $this->assign("show", 0);
            return $this->fetch("editpost");
        }
    }

    public function updatestatepost()
    {
        $result = model("article")->updatestatepost();
        return $this->success($result);
    }
}