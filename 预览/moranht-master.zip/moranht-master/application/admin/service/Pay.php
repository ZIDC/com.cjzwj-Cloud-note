<?php

namespace app\admin\service;

use app\admin\service\Alipay;
use app\admin\service\Ypay;
use app\admin\service\Yipay;

class Pay
{
    /**
     * @brief 创建支付类实例
     * @param $payment_id int 支付方式ID
     * @return 返回支付插件类对象
     */
    public static function createPaymentInstance($payment_id)
    {
        $paymentRow = self::getPaymentById($payment_id);
        if ($paymentRow != null && $paymentRow["class_name"] != "") {
            $path = "../application/admin/service/" . $paymentRow["class_name"] . ".php";
            if (!is_file($path)) {
                return "支付类对象未找到";
            }
            if ($payment_id == 0) {
                $payment = new Alipay();
            } elseif ($payment_id == 3) {
                $payment = new Ypay();
            } else {
                $payment = new Yipay();
            }
            // $payment = new $paymentRow["class_name"];
            return $payment;
        } else {
            return "支付方式不存在";
        }
    }

    /**
     * @brief 根据支付方式配置编号  获取该插件的详细配置信息
     * @param $payment_id int    支付方式ID
     * @return 返回支付插件类对象
     */
    public static function getPaymentById($payment_id)
    {
        $paymentRow = db("payment")->where("payment_id", $payment_id)->find();
        return $paymentRow;
    }
}
