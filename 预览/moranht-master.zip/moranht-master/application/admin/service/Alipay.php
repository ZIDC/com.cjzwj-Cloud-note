<?php
/*
 * @Descripttion: 支付方法
 * @version: 1.0
 * @Author: 默然
 * @Date: 2022-09-26 21:52:50
 * @LastEditors: 默然
 * @LastEditTime: 2022-10-04 21:26:10
 */

namespace app\admin\service;

use Ldtech\Alipay\AopClient as AlipayAopClient;
use Ldtech\Alipay\Request\AlipayTradePrecreateRequest;
use Ldtech\Alipay\Request\AlipayTradeQueryRequest;
use stdClass;
use think\facade\Request;

class Alipay
{
    /**
     * 创建当面付订单
     *
     * $paymentRow  //支付信息
     * $orderdata //订单信息
     */
    function createPaymentOrder($paymentRow, $orderdata)
    {
        $aop = new AlipayAopClient();
        $aop->gatewayUrl = $paymentRow["pay_url"];
        $aop->appId =  $paymentRow["appid"];
        $aop->rsaPrivateKey = $paymentRow["private_key"];
        $aop->alipayrsaPublicKey = $paymentRow["public_key"];
        $aop->apiVersion = '1.0';
        $aop->signType = "RSA2";
        $aop->postCharset = "UTF-8";
        $aop->format = "json";
        $object = new stdClass();
        $object->out_trade_no = $orderdata["out_trade_no"];
        $object->total_amount = $orderdata["total_amount"];
        $object->subject = $orderdata["subject"];

        $json = json_encode($object);
        $request = new AlipayTradePrecreateRequest();
        $request->setNotifyUrl("");
        $request->setBizContent($json);
        $result = $aop->execute( $request);

        $responseNode = str_replace(".", "_", $request->getApiMethodName()) . "_response";
        $resultCode = $result->$responseNode->code;
        if (!empty($resultCode) && $resultCode == 10000) {
            return json_encode($result);
        } else {
            return json_encode($result);
        }
    }

    //查询订单
    function queryOrder($paymentRow,$order_no)
    {
        $aop = new AlipayAopClient();
        $aop->gatewayUrl = 'https://openapi.alipay.com/gateway.do';
        $aop->appId =  $paymentRow["appid"];
        $aop->rsaPrivateKey = $paymentRow["private_key"];
        $aop->alipayrsaPublicKey = $paymentRow["public_key"];
        $aop->apiVersion = '1.0';
        $aop->signType = 'RSA2';
        $aop->postCharset = "UTF-8";
        $aop->format = 'json';
        $object = new stdClass();
        $object->out_trade_no = $order_no;
        $json = json_encode($object);
        $request = new AlipayTradeQueryRequest();
        $request->setBizContent($json);
        $result = $aop->execute($request);

        $responseNode = str_replace(".", "_", $request->getApiMethodName()) . "_response";
        $resultCode = $result->$responseNode->code;
        if (!empty($resultCode) && $resultCode == 10000) {
            $result_trade_status = $result->$responseNode->trade_status;
            if($result_trade_status == "TRADE_SUCCESS"){
                $rs = [
                    "trade_no" => $result->$responseNode->trade_no,
                    "send_pay_date" => $result->$responseNode->send_pay_date,
                ];
                return ["code" => 200,"data"=> $rs];
            }else{
                return ["code" => 400,"data"=> $result];
            }
        } else {
            return ["code" => 400,"data"=> $result];
        }
    }
}
