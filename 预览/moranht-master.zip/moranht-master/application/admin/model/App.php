<?php

namespace app\admin\model;

use app\admin\validate\App as ValidateApp;
use think\Db;
use think\Model;

class App extends Model
{
    protected $pk = 'appid';

    //获取所有app
    public function getAllApps($data)
    {
        $result = $this->where("appname","like","%{$data["appname"]}%")->order($data["sort"], $data["sortOrder"])->limit($data["limit"])->page($data["page"])->select();
        foreach($result as $key => $value){
            $result[$key]["countview"] = model("view")->countview($value["appid"]);
            $result[$key]["versioncode"] = model("appupdate")->getnewappupdate($value["appid"])["versioncode"];
        }
        $count = $this->where("appname","like","%{$data["appname"]}%")->count();
        return json(["rows" => $result, "total" => $count]);
    }

    public function add($data)
    {
        $validate = new ValidateApp();
        if(!$validate->scene('add')->check($data)){
            return $validate->getError();
        }
        $adddata = [
            "appname" => $data["appname"],
            "appicon" => "/android.png",
            "grade" => "[0 => '名称1',100=>'名称2',200=>'名称3',300=>'名称4',400=>'名称5']",
            "create_time" => date("Y-m-d H:i:s",time()),
            "signkey" => getRandChar(16),
        ];
        $res = $this->save($adddata);
        if($res > 0){
            return 1;
        }else{
            return "添加失败";
        }
    }

    /**
     * 修改app状态
     *
     * @param [type] $appid  数组
     * @param integer $appstate  状态 0正常 1禁用
     * @return string
     */
    public function editstatus($appid,$appstate = 0)
    {
        if(!is_array($appid)){
            return "服务器错误";
        }
        if($appstate == 0){
            //启用状态
            foreach($appid as $key=>$value){
                $this->where("appid",$value)->update(["is_state"=>0]);
            }
            return 1;
        }else{
            foreach($appid as $key=>$value){
                $this->where("appid",$value)->update(["is_state"=>1]);
            }
            return 1;
        }
    }

    public function deleteapp($appid)
    {
        if(!is_array($appid)){
            return "服务器错误";
        }
        foreach($appid as $key=>$value){
            $this->where("appid",$value)->delete();
            Db::name("appdownload")->where("appid",$value)->delete();
            Db::name("appnotice")->where("appid",$value)->delete();
            Db::name("appupdate")->where("appid",$value)->delete();
            Db::name("article")->where("appid",$value)->delete();
            Db::name("comments")->where("appid",$value)->delete();
            Db::name("follow")->where("appid",$value)->delete();
            Db::name("invitation")->where("appid",$value)->delete();
            Db::name("km")->where("appid",$value)->delete();
            Db::name("message")->where("appid",$value)->delete();
            Db::name("message_user")->where("appid",$value)->delete();
            Db::name("notes")->where("appid",$value)->delete();
            Db::name("order")->where("appid",$value)->delete();
            Db::name("plate")->where("appid",$value)->delete();
            Db::name("shop")->where("appid",$value)->delete();
            Db::name("sign")->where("appid",$value)->delete();
            Db::name("user")->where("appid",$value)->delete();
            Db::name("view")->where("appid",$value)->delete();
        }
        return 1;
    }

    public function getappinfo($appid)
    {
        $result = $this->where("appid",$appid)->find();
        $result["appnotice"] = model("appnotice")->getnewnotice($appid);
        $result["appupdate"] = model("appupdate")->getnewappupdate($appid);
        return $result;
    }

    public function edit($data)
    {
        $validate = new ValidateApp();
        if(!$validate->scene('edit')->check($data)){
            return $validate->getError();
        }
        //拿出公告的修改内容
        $appnoticedata = [
            "title" => $data["title"],
            "content" => $data["content"],
            "appid" => $data["appid"],
        ];
        model('appnotice')->add($appnoticedata);
        //拿出更新的修改内容
        $appupdatedata = [
            "versioncode" => $data["versioncode"],
            "content" => $data["updatecontent"],
            "download" => $data["download"],
            "appid" => $data["appid"],
        ];
        model('appupdate')->add($appupdatedata);
        $appid = $data["appid"];
        unset($data["appid"]);
        $result = $this->allowField(true)->save($data,["appid"=>$appid]);
        return 1;
    }

}