<?php

namespace app\admin\model;

use think\Model;

class Payment extends Model
{
    public function getpaymentlist()
    {
        $result = $this->select();
        return $result;
    }

    public function getpaymentinfo($id)
    {
        $result = $this->where("id",$id)->find();
        return $result;
    }

    public function edit($data)
    {
        $id = $data["id"];
        unset($data["id"]);
        $result = $this->save($data,["id"=>$id]);
        return 1;
    }
}