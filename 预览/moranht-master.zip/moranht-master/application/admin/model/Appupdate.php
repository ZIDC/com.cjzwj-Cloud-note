<?php

namespace app\admin\model;

use think\Model;

class Appupdate extends Model
{
    public function getnewappupdate($appid)
    {
        $result = $this->where("appid",$appid)->order("time","desc")->limit(1)->find();
        if(!$result){
            $result["versioncode"] = "1.0";
            $result["content"] = "";
            $result["download"] = "";
            $result["time"] = "";
        }
        return $result;
    }

    public function add($data)
    {
        $result = $this->where("versioncode",$data["versioncode"])->find();
        if($result){
            $versioncode = $data["versioncode"];
            unset($data["versioncode"]);
            $data["time"] = date("Y-m-d H:i:s",time());
            $this->allowField(true)->save($data,["versioncode"=>$versioncode]);
        }else{
            $data["time"] = date("Y-m-d H:i:s",time());
            $this->allowField(true)->save($data);
        }
    }

}