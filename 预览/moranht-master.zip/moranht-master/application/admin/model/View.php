<?php

namespace app\admin\model;

use think\Model;

class View extends Model
{
    public function countview($appid)
    {
        $count = $this->where("appid",$appid)->where("type",0)->count();
        return $count;
    }
}