<?php

namespace app\admin\model;

use think\Model;

class Appnotice extends Model
{
    public function getnewnotice($appid)
    {
        $result = $this->where("appid",$appid)->order("time","desc")->limit(1)->find();
        if(!$result){
            $result["title"] = "";
            $result["content"] = "";
            $result["time"] = "";
        }
        return $result;
    }

    public function add($data)
    {
        $result = $this->where("title",$data["title"])->where("content",$data["content"])->find();
        if(!$result){
            $data["time"] = date("Y-m-d H:i:s",time());
            $this->allowField(true)->save($data);
        }
    }

}