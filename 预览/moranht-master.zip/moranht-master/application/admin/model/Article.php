<?php

namespace app\admin\model;

use app\admin\validate\Bbs;
use think\Model;

class Article extends Model
{
    public function getpostlist($data)
    {
        $result = db("article")
            ->alias("p")
            ->join("app a", "a.appid=p.appid")
            ->join("plate pl", "pl.id=p.plateid")
            ->join("user u", "u.id=p.userid")
            ->where($data["where"])
            ->field("p.*,a.appname,pl.platename,u.username")
            ->limit($data["limit"])->page($data["page"])
            ->order($data["sort"], $data["sortOrder"])
            ->select();
        $count = db("article")
            ->alias("p")
            ->join("app a", "a.appid=p.appid")
            ->join("plate pl", "pl.id=p.plateid")
            ->join("user u", "u.id=p.userid")
            ->where($data["where"])
            ->field("p.*,a.appname")
            ->count();
        return json(["rows" => $result, "total" => $count]);
    }

    public function addplate($data)
    {
        $validate = new Bbs();
        if (!$validate->scene('addplate')->check($data)) {
            return $validate->getError();
        }
        $data["creattime"] = date("Y-m-d H:i:s", time());
        $result = $this->allowField(true)->save($data);
        if ($result > 0) {
            return 1;
        } else {
            return "服务器错误";
        }
    }

    public function getarticleinfo($id)
    {
        $result = db("article")
            ->alias("p")
            ->join("app a", "a.appid=p.appid")
            ->join("plate pl", "pl.id=p.plateid")
            ->join("user u", "u.id=p.userid")
            ->where("p.id", $id)
            ->field("p.*,a.appname,pl.platename,u.username")
            ->find();
        return $result;
    }

    public function editarticle($data)
    {
        $validate = new Bbs();
        if (!$validate->scene('editarticle')->check($data)) {
            return $validate->getError();
        }
        $id = $data["id"];
        unset($data["id"]);
        $data["ip"] = get_real_ip();
        $data["updatetime"] = date("Y-m-d H:i:s", time());
        $result = $this->allowField(true)->save($data, ["id" => $id]);
        return 1;
    }

    public function deletepost($id)
    {
        if (!is_array($id)) {
            return "服务器错误";
        }
        foreach ($id as $key => $value) {
            $this->where("id", $value)->delete();
        }
        return 1;
    }

    public function addarticle($data)
    {
        $validate = new Bbs();
        if (!$validate->scene('addarticle')->check($data)) {
            return $validate->getError();
        }
        $userinfo = db("user")->where("username", $data["username"])->where("appid", $data["appid"])->find();
        if ($userinfo == null) {
            return "用户不存在";
        }
        //查询版块的appid
        $platemodel = new Plate();
        $plateinfo = $platemodel->getplateinfo($data["plateid"]);
        if ($plateinfo["appid"] != $data["appid"]) {
            return "不能选择其他appid的版块";
        }
        $data["userid"] = $userinfo["id"];
        $data["createtime"] = date("Y-m-d H:i:s", time());
        $data["updatetime"] = date("Y-m-d H:i:s", time());
        $data["ip"] = get_real_ip();
        $this->allowField(true)->save($data);
        return 1;
    }

    public function updatestatepost()
    {
        db("article")->where("status", 0)->update(["status" => 1]);
        return "审核成功";
    }
}
