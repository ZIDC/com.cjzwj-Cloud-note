<?php

namespace app\admin\model;

use app\admin\validate\Km as ValidateKm;
use think\Model;

class Km extends Model
{
    public function getkmlist($data, $type = 0)
    {
        $sort = isset($data["sort"]) ? $data["sort"] : 'id';
        $sortOrder = isset($data["sortOrder"]) ? $data["sortOrder"] : 'asc';
        $result = db("km")
            ->alias("k")
            ->join("app a", "k.appid=a.appid")
            ->where("k.appid", "like", "%{$data['appid']}%")
            ->where("k.km", "like", "%{$data['km']}%")
            ->where("k.state", "like", "%{$data['state']}%")
            ->where("k.classification", "like", "%{$data['classification']}%")
            ->where("k.type", $type)
            ->limit($data["limit"])->page($data["page"])
            ->field("k.*,a.appname")
            ->order($sort, $sortOrder)
            ->select();
        $count = db("km")
            ->alias("k")
            ->join("app a", "k.appid=a.appid")
            ->where("k.appid", "like", "%{$data['appid']}%")
            ->where("k.km", "like", "%{$data['km']}%")
            ->where("k.state", "like", "%{$data['state']}%")
            ->where("k.classification", "like", "%{$data['classification']}%")
            ->where("k.type", $type)
            ->field("k.*,a.appname")
            ->order($sort, $sortOrder)
            ->count();
        return json(["rows" => $result, "total" => $count]);
    }

    public function deletekm($id)
    {
        if (!is_array($id)) {
            return "服务器错误";
        }
        foreach ($id as $key => $value) {
            $this->where("id", $value)->delete();
        }
        return 1;
    }

    public function add($data)
    {
        $validate = new ValidateKm();
        if (!$validate->scene('add')->check($data)) {
            return $validate->getError();
        }
        $adddata = [
            "exp" => $data["exp"],
            "money" => $data["money"],
            "viptime" => $data["viptime"],
            "appid" => $data["appid"],
            "classification" => $data["classification"],
        ];
        $resdata = [];
        for ($i = 0; $i < $data["num"]; $i++) {
            $km = getRandChar($data['length']);
            $rs = $this->where("appid", $data["appid"])->where("km", $km)->where("type",1)->find();
            if ($rs == null) {
                $resdata[$i] = $adddata;
                $resdata[$i]["km"] = $km;
                $resdata[$i]["creattime"] = date("Y-m-d H:i:s", time());
            }
        }
        $this->saveAll($resdata);
        return 1;
    }

    public function exportdownload($data, $type = 0)
    {
        $result = db("km")
            ->alias("k")
            ->join("app a", "k.appid=a.appid")
            ->where("k.appid", "like", "%{$data['appid']}%")
            ->where("k.km", "like", "%{$data['km']}%")
            ->where("k.state", "like", "%{$data['state']}%")
            ->where("k.classification", "like", "%{$data['classification']}%")
            ->where("k.type", $type)
            ->field("k.*,a.appname")
            ->select();
        return $result;
    }

    public function addloginkm($data)
    {
        $validate = new ValidateKm();
        if (!$validate->scene('addloginkm')->check($data)) {
            return $validate->getError();
        }
        $adddata = [
            "expire" => $data["expire"],
            "appid" => $data["appid"],
            "classification" => $data["classification"],
            "type" => 1,
        ];
        $resdata = [];
        for ($i = 0; $i < $data["num"]; $i++) {
            $km = getRandChar($data['length']);
            $rs = $this->where("appid", $data["appid"])->where("km", $km)->where("type",1)->find();
            if ($rs == null) {
                $resdata[$i] = $adddata;
                $resdata[$i]["km"] = $km;
                $resdata[$i]["creattime"] = date("Y-m-d H:i:s", time());
            }
        }
        $this->saveAll($resdata);
        return 1;
    }

}
