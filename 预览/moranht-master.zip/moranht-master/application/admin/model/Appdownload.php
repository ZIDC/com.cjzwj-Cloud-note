<?php

namespace app\admin\model;

use think\Model;

class Appdownload extends Model
{
    public function getappdownloadlist()
    {
        $result = db('appdownload')->alias("d")->join("app a","a.appid=d.appid")->field("d.*,a.appname")->select();
        return $result;
    }

    public function getappdownloadinfo($id)
    {
        $result = $this->where("id",$id)->find();
        return $result;
    }

    public function edit($data)
    {
        $id = $data["id"];
        unset($data["id"]);
        $result = $this->allowField(true)->save($data,["id"=>$id]);
        return 1;
    }

    public function add($data)
    {
        $rs = $this->where("appid",$data["appid"])->find();
        if($rs){
            return "已经添加过此app了";
        }
        $data["code"] = md5(time());
        $result = $this->allowField(true)->save($data);
        return 1;
    }
}