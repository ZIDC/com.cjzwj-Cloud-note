<?php

namespace app\admin\model;

use think\Model;

class message extends Model
{
    public function getmessagelist()
    {
        $result = db("message")
        ->alias("m")
        ->join("app a","a.appid=m.appid")
        ->where("m.sender_id",0)
        ->where("m.type",0)
        ->field("m.*,a.appname")
        ->order("m.id","asc")
        ->paginate(10);
        return $result;
    }

    public function add($data)
    {
        $data["time"] = date("Y-m-d H:i:s",time());
        $result = $this->save($data);
        if($result > 0){
            return 1;
        }else{
            return 2;
        }
    }

    public function delmsg($id)
    {
        $result = $this->where("id",$id)->delete();
        if($result > 0){
            return 1;
        }else{
            return 2;
        }
    }
}