<?php

namespace app\admin\model;

use think\Model;

class System extends Model
{
    protected $table = 'mr_config';

    //获取当前value值
    public function getValueBytype($type)
    {
        $result = $this->where("type", $type)->find();
        $value = $result["value"];
        $value = json_decode($value,true);
        return $value;
    }

    public function edit($data)
    {
        $result = $this->where("type",$data["type"])->update(["value"=>$data["data"]]);
        return 1;
    }
}