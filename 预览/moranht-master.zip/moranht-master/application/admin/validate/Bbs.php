<?php

namespace app\admin\validate;

use think\Validate;

class Bbs extends Validate
{
    protected $rule =   [
        'platename|板块名称'  => 'require',
        'plateicon|板块icon'   => 'require',
        'satus|发帖权限'   => 'require|number',
        'appid|appid'   => 'require|number',
        'title|帖子标题' => 'require',
        'content|帖子内容' => 'require',
        'username' => 'require',
        'plateid' => 'require',
        'appid' => 'require',
        'status' => 'require',
        'top' => 'require',
        'popular' => 'require',
        'is_type' => 'require',
    ];

    //验证场景
    protected $scene = [
        'addplate'  =>  ['platename','plateicon','satus','appid'],
        'updateplate'  =>  ['platename','plateicon','satus'],
        'editarticle'  =>  ['title','content'],
        'addarticle'  =>  ['title','content','username','plateid','appid','status','top','popular','is_type'],
    ];



}