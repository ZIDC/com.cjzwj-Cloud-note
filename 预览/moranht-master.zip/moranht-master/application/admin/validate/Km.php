<?php

namespace app\admin\validate;

use think\Validate;

class Km extends Validate
{
    protected $rule =   [
        'km|卡密'  => 'require',
        'exp|经验' => 'require|number',
        'money|金币' => 'require|number',
        'viptime|会员天数' => 'require|number',
        'appid|appid' => 'require|number',
        'num|数量' => 'require|number',
        'length|长度' => 'require|number',
        'expire|过期时间' => 'require|number',
    ];

    //验证场景
    protected $scene = [
        'add' => ['exp','money','viptime','appid','num','length'],
        'addloginkm' => ['expire','appid','num','length'],
    ];



}