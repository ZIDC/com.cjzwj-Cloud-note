<?php

namespace app\admin\validate;

use think\Validate;

class Shop extends Validate
{
    protected $rule =   [
        'name|商品名称'  => 'require',
        'subimages|商品图片' => 'require',
        'detail|商品描述' => 'require',
        'price|价格' => 'require|number',
        'appid|appid' => 'require|number',
        'stock|库存' => 'require|number',
    ];

    //验证场景
    protected $scene = [
        'add' => ['name','subimages','detail','price','appid','stock'],
    ];



}