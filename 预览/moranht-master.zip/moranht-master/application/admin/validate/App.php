<?php

namespace app\admin\validate;

use think\Validate;

class App extends Validate
{
    protected $rule =   [
        'appname|app名称'  => 'require',
        'appicon|app图标'   => 'require',
        'introduction|应用简介'   => 'require',
        'author|开发者联系方式'   => 'require',
        'group|官方群组' => 'require|number',
        'zc_money|注册赠送积分' => 'require|number',
        'zc_exp|注册赠送积分' => 'require|number',
        'zc_vip|注册赠送会员' => 'require|number',
        'sign_money|签到赠送金币' => 'require|number',
        'sign_exp|签到赠送积分' => 'require|number',
        'sign_vip|签到赠送会员' => 'require|number',
        'invitation_money|邀请人获得金币' => 'require|number',
        'invitation_exp|邀请人获得金币' => 'require|number',
        'invitation_vip|邀请人获得会员' => 'require|number',
        'grade|等级' => 'require',
        'title|公告标题' => 'require',
        'content|公告内容' => 'require',
        'versioncode|版本号' => 'require',
        'updatecontent|更新内容' => 'require',
        'download|下载链接' => 'require',
    ];

    //验证场景
    protected $scene = [
        'add'  =>  ['appname'],
        'edit'  =>  ['appname', 'appicon', 'introduction', 'author', 'group', 'zc_money', 'zc_exp', 'zc_vip', 'sign_money', 'sign_exp', 'sign_vip', 'invitation_money', 'invitation_exp', 'invitation_vip', 'grade','title','content','versioncode','updatecontent','download'],
    ];
}
