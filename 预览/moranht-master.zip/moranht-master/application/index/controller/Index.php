<?php

namespace app\index\controller;

use app\admin\model\Appnotice;
use app\admin\model\Appupdate;
use think\Controller;
use think\facade\Request;
use think\helper\Time;

class Index extends Controller
{
    public function index()
    {
        return '<style type="text/css">*{ padding: 0; margin: 0; } div{ padding: 4px 48px;} a{color:#2E5CD5;cursor: pointer;text-decoration: none} a:hover{text-decoration:underline; } body{ background: #fff; font-family: "Century Gothic","Microsoft yahei"; color: #333;font-size:18px;} h1{ font-size: 100px; font-weight: normal; margin-bottom: 12px; } p{ line-height: 1.6em; font-size: 42px }</style><div style="padding: 24px 48px;"> <h1>:) </h1><p> ThinkPHP V5.1<br/><span style="font-size:30px">16载初心不改（2006-2022） - 你值得信赖的PHP框架</span></p></div><script type="text/javascript" src="https://e.topthink.com/Public/static/client.js"></script><think id="eab4b9f840753f8e7"></think>';
    }

    public function code($code = "")
    {
        $result = db("appdownload")
            ->alias("d")
            ->join("app a", "a.appid=d.appid")
            ->field("d.*,a.appicon,a.introduction,a.appname")
            ->where("code", $code)
            ->find();
        if ($result == null) {
            return $this->fetch("exception_html/404");
        }
        $appnotice = new Appnotice();
        $result["appnotice"] = $appnotice->getnewnotice($result["appid"]);
        $appupdate = new Appupdate();
        $result["appupdate"] = $appupdate->getnewappupdate($result["appid"]);
        $appupdatelist = db("appupdate")->where("appid", $result["appid"])->order("time", "desc")->select();
        $this->assign("appupdate", $appupdatelist);
        $this->assign("data", $result);
        return $this->fetch($result['template']);
    }

    public function querynotes($id = "")
    {
        $notes = db('notes')
            ->alias('n')
            ->join('user u', 'n.user_id = u.id')
            ->where('n.id', $id)
            ->field('n.*,u.usertx,u.nickname,u.username,u.title as usertitle')
            ->find();
        if ($notes == null) {
            return $this->fetch("exception_html/404");
        }
        // return json_encode($notes);
        return $this->fetch("query/querynotes")->assign('notes', $notes);
    }

    public function querypost($id = "")
    {
        $postinfo = db("article")
            ->alias("a")
            ->join("user u", "u.id=a.userid")
            ->join("plate p", "p.id=a.plateid")
            ->join("app", "app.appid=a.appid")
            ->field("a.*,u.username,u.nickname,u.usertx,u.title as usertitle,p.platename,app.appname")
            ->where("a.id", $id)
            ->find();
        if($postinfo == null){
            return $this->fetch("exception_html/404");
        }
        //本地图片
        $pic = explode(",", $postinfo["pic_url"]);
        $pic_url_array = [];
        foreach ($pic as $k => $v) {
            if ($v == "") continue;
            array_push($pic_url_array, Request::domain() . $v);
        }
        $pic_url = implode(",", $pic_url_array);
        //网络图片
        $network_pictures_start = explode(",", $postinfo["network_pictures"]);
        $network_pictures_array = [];
        foreach ($network_pictures_start as $k1 => $v1) {
            if ($v1 == "") continue;
            array_push($network_pictures_array, $v1);
        }
        $network_pictures = implode(",", $network_pictures_array);
        if ($postinfo["pic_url"] != "") {
            if ($postinfo["network_pictures"] != "") {
                $postinfo["pic_url"] = $pic_url . "," . $network_pictures;
            } else {
                $postinfo["pic_url"] = $pic_url;
            }
        } else {
            if ($postinfo["network_pictures"] != "") {
                $postinfo["pic_url"] = $network_pictures;
            } else {
                $postinfo["pic_url"] = "";
            }
        }
        $file = explode(',', $postinfo['pic_url']);
        $comment = db('comments')
            ->alias("c")
            ->join("user u", "u.id = c.userid")
            ->join("article a", "a.id = c.postid")
            ->where("c.postid", $postinfo["id"])
            ->field("c.*,u.username,u.nickname,u.usertx,u.title as usertitle,a.title as posttitle")
            ->limit(10)
            ->select();
        foreach ($comment as $key => $value) {
            $comment[$key]["usertx"] = $value["usertx"];
            //假入有上级评论则插入
            //上级评论者用户昵称
            $comment[$key]["parentnickname"] = "";
            //上级评论内容
            $comment[$key]["parentcontent"] = "";
            if ($value["parentid"] != 0) {
                $parentcommentinfo = db("comments")
                    ->alias("c")
                    ->join("user u", "u.id = c.userid")
                    ->join("article a", "a.id = c.postid")
                    ->where("c.id", $value["parentid"])
                    ->field("c.id,c.content,u.nickname")
                    ->find();
                //上级评论者用户昵称
                $comment[$key]["parentnickname"] = $parentcommentinfo["nickname"];
                //上级评论内容
                $comment[$key]["parentcontent"] = $parentcommentinfo["content"];
            }
        }
        $app = db("appupdate")->where("appid", $postinfo["appid"])->order("time", "desc")->limit(1)->find();
        return $this->fetch("query/querypost")
            ->assign('postdata', $postinfo)
            ->assign('file', $file)
            ->assign('comment', $comment)
            ->assign('app', $app);
    }
}
